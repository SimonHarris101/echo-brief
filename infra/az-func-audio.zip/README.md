az cosmosdb sql role assignment create `
>     --resource-group "ai-voice-agent" `
>     --account-name "voice" `
>     --role-definition-id "/subscriptions/7febc3da-6cf5-4dd8-9de8-893009904239/resourceGroups/ai-voice-agent/providers/Microsoft.DocumentDB/databaseAccounts/voice/sqlRoleDefinitions/00000000-0000-0000-0000-000000000002" `
>     --principal-id "9f26c927-81ff-439e-bfa4-15849b719f28" `
>     --scope "/subscriptions/7febc3da-6cf5-4dd8-9de8-893009904239/resourceGroups/ai-voice-agent/providers/Microsoft.DocumentDB/databaseAccounts/voice"